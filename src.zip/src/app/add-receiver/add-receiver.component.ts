import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../Service/data/data.service';
import { AbstractControl, NgForm, ValidationErrors, ValidatorFn } from '@angular/forms';

@Component({
  selector: 'app-add-receiver',
  templateUrl: './add-receiver.component.html',
  styleUrls: ['./add-receiver.component.css']
})
export class AddReceiverComponent {

  selectedCountry: string;
  countryData: any = {};
  countries: any = [];
  receiverList: Array<Object> = [];

  isFormSubmitted=false;
  

  constructor(private router: Router, private http: HttpClient, private data: DataService) { }
 

  isPhoneNumberValid(value :string): boolean {
    return /^\d{10}$/.test(value);
  }

  isString(value: any): boolean{
    return typeof value === 'string';
  }
  OnClick(form: NgForm): void {
    this.isFormSubmitted=true;
    if(form.invalid 
      // ||  !this.isPhoneNumberValid(form.value.phone)
    ){
      alert("Please fill all the details");
    }
    else{
      this.addReceiver(form.value);
    }
  }
 
 

  addReceiver(user: any){
    console.log(user);
      this.http.post("http://localhost:3000/CurrentData",user)
          .subscribe((result)=>{
            console.log(result);
            alert("Receiver data added");
            this.router.navigateByUrl('/myReceiver');
          })
}
isReqMidName() {
  const country = this.selectedCountry
  let check = false;
  console.log("country", this.selectedCountry);

  if (country && this.countryData) {
    switch (country) {
      case 'USA': {
        check = this.countryData[0].USA.isReqMidName;
      }
        break;
        case 'India':
        {
          check = this.countryData[0].India.isReqMidName;
        }
        break;

        case 'Dubai': {
          check = this.countryData[0].Dubai.isReqMidName;
        }
        break;

        case 'Qatar': {
          check = this.countryData[0].Qatar.isReqMidName;
        }
        break;
      default:
        check = false;
    }

  }


  else {
    check = false;
  }
  console.log(check);
  return check;
}

isReqLastName() {
  const country = this.selectedCountry
  let check = false;
  console.log("country", this.selectedCountry);
  if (country && this.countryData) {
    switch (country) {
      case 'USA': {
        check = this.countryData[0].USA.isReqLastName;
      }
        break;

      case 'India':

        {
          check = this.countryData[0].India.isReqLastName;
        }
        break;
        
        case 'Dubai': {
          check = this.countryData[0].Dubai.isReqLastName;
        }
        break;

        case 'Qatar': {
          check = this.countryData[0].Qatar.isReqLastName;
        }
        break;
      default:
        check = false;
    }

  }


  else {
    check = false;
  }
  console.log(check);
  return check;
}

ngOnInit(): void {
  this.data.getConfig().subscribe((data: Array<Object>) => {
    this.countryData = data;                           // all country data 
    console.warn("data", this.countryData);
    this.countries = Object.keys(this.countryData[0]); //get the countries
    console.log(this.countries);
    console.log("country", this.selectedCountry);

    // console.warn(this.countryData);

  });
  // this.receiver.saveReceiver();
  this.data.getReceivers().subscribe((result: Array<Object>) => {
    this.receiverList = result;
    // console.log(result);

    console.log(this.receiverList);
  })
}

  //   CodeForSelectedCountry(){
  //     // return this.countryData[0];
  //     const country = this.selectedCountry;
  //     let check = false;

  //     if (country && this.countryData) {
  //       switch (country) {
  //         case 'USA': {
  //           check = this.countryData[0]?.USA?.code;
  //         }
  //           break;
    
  //         case 'India':
    
  //           {
  //             check = this.countryData[0]?.India?.code;
  //           }
  //           break;
            
  //           case 'Dubai': {
  //             check = this.countryData[0]?.Dubai?.code;
  //           }
  //           break;
    
  //           case 'Qatar': {
  //             check = this.countryData[0]?.Qatar?.code;
  //           }
  //           break;
  //         default:
  //           check = false;
  //       }
  //   }
  //   console.log(check);
  //   return check;
  // }


ngDocheck(): void {
  console.log(this.isReqMidName());


}
}
